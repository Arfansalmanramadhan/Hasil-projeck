<?php  
require 'function1.php';
$id = $_GET["id"];

if( hapus($id) >0){
	echo header("Location: data.php");
	exit;
}

$id = $_GET["id"];

if( hapus2($id) >0){
	echo header("Location: data.php");
	exit;
}

$id = $_GET["id"];

if( hapus3($id) >0){
	echo header("Location: data.php");
	exit;
}

$id = $_GET["id"];

if( hapus4($id) >0){
	echo header("Location: data.php");
	exit;
}

$id = $_GET["id"];

if( hapus5($id) >0){
	echo header("Location: data.php");
	exit;
}

$id = $_GET["id"];

if( hapus5($id) >0){
	echo header("Location: data.php");
	exit;
}

$id = $_GET["id"];

if( hapus6($id) >0){
	echo header("Location: data.php");
	exit;
}
?>