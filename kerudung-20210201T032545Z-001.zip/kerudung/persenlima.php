<?php   	
require 'function1.php';

if( isset($_POST["submit"])) {
	global $conn;
	if( data5($_POST) > 0){

		echo header("Location: transfer.php");
		
		exit;
	} 
}	
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    	<style >
    		.container {
    			padding-top: 50px;
    			padding-right: 500px;
    		}
    	</style>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Khimar Jumbo Tali Wolfisr</title>
  </head>
  <body>
  	<div class="container">
  		<div class="row">
  			<div class="col">
  				<h1>Khimar Jumbo Tali Wolfisr</h1>
  			</div>
  		</div>
  	</div>
  	<div class="container ">
  		<div class="row">
  			<div class="col">
	  			<form action=""  method="post">
				  <div class="form-group">
				    <label for="nama">Nama Lengkap</label>
				    <input type="text" name="nama" class="form-control" id="nama"  size="100" autocomplete="off" required=""  placeholder="Masukkan nama Lengkap anda">
				    
				  </div>
				  <div class="form-group">
				    <label for="alamat">Alamat</label>
				    <input type="text" name="alamat" class="form-control" id="alamat" size="100" autocomplete="off" required=""  placeholder="Masukkan alamat">
				  </div>
				  <div class="form-group">
				    <label for="kecamatan">Kecamatan</label>
				    <input type="text" name="kecamatan" class="form-control" id="kecamatan" size="100" autocomplete="off" required=""  placeholder="Masukkan kecamatan">
				  </div>
				  <div class="form-group">
				    <label for="kabupaten">Kabupaten</label>
				    <input type="text" name="kabupaten" class="form-control" id="kabupaten" size="100" autocomplete="off" required=""  placeholder="Masukan kabupaten">
				  </div>
				  <div class="form-group">
				    <label for="telepon">No WhatsApp</label>
				    <input type="text" name="telepon" class="form-control" id="telepon" size="100" autocomplete="off" required=""  placeholder="Masukkan No WhatsApp">
				  </div>
				   <div class="form-group col-md-4">
				      <label for="warna">Warna</label>
				      <select name="warna" id="warna" height="50" required="">
				        <option selected>Black</option>
				        <option>Abu Muda</option>
				        <option>Coksu</option>
				        <option>Maroo</option>
				        <option>Dusty Pink</option>
				        <option>Lemon</option>
				        <option>Navy</option>
				        <option>Lavender</option>
				        <option>Botol</option>
				        <option>Army</option>
				        <option>Mocca</option>
				        <option>Abu Tua</option>
				        <option>Mustard</option>
				        <option>Hijau Tosca</option>
				        <option>Milo</option>
				        <option>Hijau Wardah</option>
				        <option>Birel</option> 
				      </select>
				    </div>
				 
				  <button type="submit" name="submit" >Persan</button>
				</form>
			</div>	
  		</div>
  	</div>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>