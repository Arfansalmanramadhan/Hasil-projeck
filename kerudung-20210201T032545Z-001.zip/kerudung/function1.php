<?php  	
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "kerudung");

function query($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}


function data($data){
	global $conn;

	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$kecamatan = htmlspecialchars($data["kecamatan"]);
	$kabupaten = htmlspecialchars($data["kabupaten"]);
	$telepon = htmlspecialchars($data["telepon"]);
	$warna = htmlspecialchars($data["warna"]);

	$query = "INSERT INTO kerudungsatu
				VALUES 	
				('', '$nama', '$alamat', '$kecamatan', '$kabupaten', '$telepon', '$warna') ";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);


}
function hapus($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM  kerudungsatu WHERE id = $id");
	return mysqli_affected_rows($conn);

}

function query2($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}


function data2($data){
	global $conn;

	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$kecamatan = htmlspecialchars($data["kecamatan"]);
	$kabupaten = htmlspecialchars($data["kabupaten"]);
	$telepon = htmlspecialchars($data["telepon"]);
	$warna = htmlspecialchars($data["warna"]);

	$query = "INSERT INTO kerudungdua
				VALUES 	
				('', '$nama', '$alamat', '$kecamatan', '$kabupaten', '$telepon', '$warna') ";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);


}
function hapus2($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM  kerudungdua WHERE id = $id");	
	return mysqli_affected_rows($conn);

}


function query3($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}


function data3($data){
	global $conn;

	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$kecamatan = htmlspecialchars($data["kecamatan"]);
	$kabupaten = htmlspecialchars($data["kabupaten"]);
	$telepon = htmlspecialchars($data["telepon"]);
	$warna = htmlspecialchars($data["warna"]);

	$query = "INSERT INTO kerudungtiga
				VALUES 	
				('', '$nama', '$alamat', '$kecamatan', '$kabupaten', '$telepon', '$warna') ";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);


}
function hapus3($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM  kerudungtiga WHERE id = $id");	
	return mysqli_affected_rows($conn);

}


function query4($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)){
		$rows[] = $row;
	}
	return $rows;
}

function data4($data){
	global $conn;

	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$kecamatan = htmlspecialchars($data["kecamatan"]);
	$kabupaten = htmlspecialchars($data["kabupaten"]);
	$telepon = htmlspecialchars($data["telepon"]);
	$warna = htmlspecialchars($data["warna"]);

	$query = "INSERT INTO kerudungempat
				VALUES
				('', '$nama', '$alamat', '$kecamatan', '$kabupaten', '$telepon', '$warna')";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function hapus4($id){
		global $conn;
	mysqli_query($conn, "DELETE FROM  kerudungempat WHERE id = $id");	
	return mysqli_affected_rows($conn);
}


function query5($query){
	global $conn;		
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)){
		$rows[] = $row;
	}
	return $rows;
}


function data5($data){
	global $conn;

	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$kecamatan = htmlspecialchars($data["kecamatan"]);
	$kabupaten = htmlspecialchars($data["kabupaten"]);
	$telepon = htmlspecialchars($data["telepon"]);
	$warna = htmlspecialchars($data["warna"]);

	$query = "INSERT INTO kerudunglima
				VALUES
				('', '$nama', '$alamat', '$kecamatan', '$kabupaten', '$telepon', '$warna')";
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}


function hapus5($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM kerudunglima WHERE id = $id");
	return mysqli_affected_rows($conn);
}

function query6($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)){
		$rows[] = $row;
	}
	return $rows;
}

function data6($data){
	global $conn;
	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$kecamatan = htmlspecialchars($data["kecamatan"]);
	$kabupaten = htmlspecialchars($data["kabupaten"]);
	$telepon = htmlspecialchars($data["telepon"]);
	$warna = htmlspecialchars($data["warna"]);

	$query = "INSERT INTO kerudungenam
				VALUES
				('', '$nama', '$alamat', '$kecamatan', '$kabupaten', '$telepon', '$warna')";
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function hapus6($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM kerudungenam WHERE id =$id");
	return mysqli_affected_rows($conn);
}




?>