<?php  
require 'function1.php';

$moss = query("SELECT * FROM kerudungsatu");
$mosj = query2("SELECT * FROM kerudungdua");
$cerub = query3("SELECT * FROM kerudungtiga");
$juntw = query4("SELECT * FROM kerudungempat");
$junw = query5("SELECT * FROM kerudunglima");
$paj = query6("SELECT * FROM kerudungenam");
?>
  <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Halaman Admin</title>
  </head>
  <body>
   


   <div class="container">
    <div class="row">
      <div class="col-md">
      <h2>Bergo Moscrepe Standar</h2>
       <table border="1" cellpadding="10" cellspacing="0" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Alamat</th>
          <th scope="col">Kecamatan</th>
          <th scope="col">Kabupaten</th>
          <th scope="col">No HP/Whats app</th>
          <th scope="col">Warna</th>
          <th scope="col">Hapus</th>
        </tr>
      </thead>
      <tbody> 
        <?php $i = 1; ?>
        <?php foreach($moss as $jab1): ?>
          <tr>
            <td><?php echo $i; ?></td>  
            <td><?php echo $jab1["nama"];  ?></td>
            <td><?php echo $jab1["alamat"];  ?></td>
            <td><?php echo $jab1["kecamatan"];  ?></td>
            <td><?php echo $jab1["kabupaten"];  ?></td>
            <td><?php echo $jab1["telepon"];  ?></td>
            <td><?php echo $jab1["warna"];  ?></td> 
            <td> <a href="hapus.php?id=<?php echo $jab1["id"]; ?>">Hapus</a></td>         
          </tr>
          <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>    
    </div>

    <br><br><br>
 
    <div class="row">
      <div class="col-md">
      <h2>Bergo Moscrepe Jumbo</h2>
       <table border="1" cellpadding="10" cellspacing="0" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Alamat</th>
          <th scope="col">Kecamatan</th>
          <th scope="col">Kabupaten</th>
          <th scope="col">No HP/Whats app</th>
          <th scope="col">Warna</th>
          <th scope="col">Hapus</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach($mosj as $jab2): ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $jab2["nama"];  ?></td>
            <td><?php echo $jab2["alamat"];  ?></td>
            <td><?php echo $jab2["kecamatan"];  ?></td>
            <td><?php echo $jab2["kabupaten"];  ?></td>
            <td><?php echo $jab2["telepon"];  ?></td>
            <td><?php echo $jab2["warna"];  ?></td> 
            <td> <a href="hapus.php?id=<?php echo $jab2["id"]; ?>">Hapus</a></td>         
          </tr>
          <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>    
    </div>

    <br><br><br>
    <div class="row">
      <div class="col-md">
      <h2>Pashmina Ceruty Babydoll</h2>
       <table border="1" cellpadding="10" cellspacing="0" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Alamat</th>
          <th scope="col">Kecamatan</th>
          <th scope="col">Kabupaten</th>
          <th scope="col">No HP/Whats app</th>
          <th scope="col">Warna</th>
          <th scope="col">Hapus</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach($cerub as $jab3): ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $jab3["nama"];  ?></td>
            <td><?php echo $jab3["alamat"];  ?></td>
            <td><?php echo $jab3["kecamatan"];  ?></td>
            <td><?php echo $jab3["kabupaten"];  ?></td>
            <td><?php echo $jab3["telepon"];  ?></td>
            <td><?php echo $jab3["warna"];  ?></td> 
            <td> <a href="hapus.php?id=<?php echo $jab3["id"]; ?>">Hapus</a></td>         
          </tr>
          <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>    
    </div>


        <br><br><br>
    <div class="row">
      <div class="col-md">
      <h2>Khimar Jumbo Non Tali Wolfis</h2>
       <table border="1" cellpadding="10" cellspacing="0" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Alamat</th>
          <th scope="col">Kecamatan</th>
          <th scope="col">Kabupaten</th>
          <th scope="col">No HP/Whats app</th>
          <th scope="col">Warna</th>
          <th scope="col">Hapus</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach($juntw as $jab5): ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $jab5["nama"];  ?></td>
            <td><?php echo $jab5["alamat"];  ?></td>
            <td><?php echo $jab5["kecamatan"];  ?></td>
            <td><?php echo $jab5["kabupaten"];  ?></td>
            <td><?php echo $jab5["telepon"];  ?></td>
            <td><?php echo $jab5["warna"];  ?></td> 
            <td> <a href="hapus.php?id=<?php echo $jab5["id"]; ?>">Hapus</a></td>         
          </tr>
          <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>    
    </div>

    <br><br><br>
    <div class="row">
      <div class="col-md">
      <h2>Khimar Jumbo  Tali Wolfis</h2>
       <table border="1" cellpadding="10" cellspacing="0" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Alamat</th>
          <th scope="col">Kecamatan</th>
          <th scope="col">Kabupaten</th>
          <th scope="col">No HP/Whats app</th>
          <th scope="col">Warna</th>
          <th scope="col">Hapus</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach($junw as $jab5): ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $jab5["nama"];  ?></td>
            <td><?php echo $jab5["alamat"];  ?></td>
            <td><?php echo $jab5["kecamatan"];  ?></td>
            <td><?php echo $jab5["kabupaten"];  ?></td>
            <td><?php echo $jab5["telepon"];  ?></td>
            <td><?php echo $jab5["warna"];  ?></td> 
            <td> <a href="hapus.php?id=<?php echo $jab5["id"]; ?>">Hapus</a></td>         
          </tr>
          <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>    
    </div><br><br><br>
    <div class="row">
      <div class="col-md">
      <h2>Pashimna Diamind Jumbo</h2>
       <table border="1" cellpadding="10" cellspacing="0" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Alamat</th>
          <th scope="col">Kecamatan</th>
          <th scope="col">Kabupaten</th>
          <th scope="col">No HP/Whats app</th>
          <th scope="col">Warna</th>
          <th scope="col">Hapus</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach($paj as $jab6): ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $jab6["nama"];  ?></td>
            <td><?php echo $jab6["alamat"];  ?></td>
            <td><?php echo $jab6["kecamatan"];  ?></td>
            <td><?php echo $jab6["kabupaten"];  ?></td>
            <td><?php echo $jab6["telepon"];  ?></td>
            <td><?php echo $jab6["warna"];  ?></td> 
            <td> <a href="hapus.php?id=<?php echo $jab6["id"]; ?>">Hapus</a></td>         
          </tr>
          <?php $i = 1; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>    
    </div>
</div>

    



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>