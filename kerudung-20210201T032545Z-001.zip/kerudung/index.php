<?php  ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- My css -->
     <style>
     .row hr {
      border: 2px solid gray;
     }
        
    </style>



    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Trihijab</title>
  </head>
  <body>
 
 
    

    <!-- card --> 
    <section class="card bg-light">
     <div class="container">
       <div class="row text-center mb-4 pt-2">
         <div class="col-md">
           <h2>Prodak</h2>
           <hr>
         </div>
       </div>
       <div class="row mt-3">
         <div class="col-md">
            <div class="card">
              <img src="img/1,.2.jpg" class="card-img-top" alt="Bergo Moscrepe Standar">
              <div class="card-body">
                <h5 class="card-title">Bergo Moscrepe Standar</h5>
                <p class="card-text">Harga: 30K/PCS</p>
                <a href="persen.php"   class="btn btn-primary">Persan</a>
              </div>
            </div>
         </div>
         <div class="col-md">
            <div class="card">
              <img src="img/1.1.jpg" class="card-img-top" alt="Bergo Moscrepe Jumbo">
              <div class="card-body">
                <h5 class="card-title">Bergo Moscrepe Jumbo</h5>
                <p class="card-text">Harga: 40K/PCS</p>
                <a href="persendua.php"  class="btn btn-primary">Persan</a>
              </div>
            </div>
         </div>
         <div class="col-md">
            <div class="card">
              <img src="img/1.3.jpg" class="card-img-top" alt="Pashmina Ceruty Babydoll">
              <div class="card-body">
                <h5 class="card-title">Pashmina Ceruty Babydoll</h5>
                <p class="card-text">Harga: 30K/PCS</p>
                <a href="persentiga.php"  class="btn btn-primary">Persan</a>
              </div>
            </div>
         </div>
       </div>
     </div>
     <div class="row mt-3 ml-5 img1  ">
         <div class="col-md">
            <div class="card">
              <img src="img/1.4.jpg" class="card-img-top" alt="Khimar Jumbo Non Tali Wolfis">
              <div class="card-body">
                <h5 class="card-title">Khimar Jumbo Non Tali Wolfis</h5>
                <p class="card-text">Harga: 45K/PCS</p>
                <a href="persenempat.php"  class="btn btn-primary">Persan</a>
              </div>
            </div>
         </div>
         <div class="col-md">
            <div class="card">
              <img src="img/1.5.jpg" class="card-img-top" alt="Khimar Jumbo Tali Wolfis">
              <div class="card-body">
                <h5 class="card-title">Khimar Jumbo Tali Wolfis</h5>
                <p class="card-text">Harga: 40K/PCS</p>
                <a href="persenlima.php"  class="btn btn-primary">Persan</a>
              </div>
            </div>
         </div>
         <div class="col-md">
            <div class="card">
              <img src="img/1.6.jpg" class="card-img-top" alt="Pashimna Diamond Jumbo">
              <div class="card-body">
                <h5 class="card-title">Pashimna Diamond Jumbo</h5>
                <p class="card-text">Harga: 40K/PCS</p>
                <a href="persenenam.php"  class="btn btn-primary">Persan</a>
              </div>
            </div>
         </div>
       </div>
     </div>

     </section>
     <section class="card bg-white ">
        <div class="container ">
       <div class="row mb-4 pt-4">
         <div class="col-md text-center">
           <h2>Sosial Media</h2>
           <hr>
         </div>
       </div>
        <div class="row">
          <div class="col-md">
            <div class="card">
              <img src="img/2.1.jpg" class="card-img-top" alt="Pashimna Diamond Jumbo">
              <div class="card-body">            
                <p class="card-text">Untuk lebih mengetahui prodak kerudung ini silangkan klik tombol di bawahh ini</p>
                <a href="https://instagram.com/trihijab07?igshid=pcgvmg1c6vey" target="_blank" class="btn btn-primary">Instagram</a>
              </div>
            </div>
         </div>
         <div class="col-md">
            <div class="card">
              <img src="img/2.2.jpg" class="card-img-top" alt="Pashimna Diamond Jumbo">
              <div class="card-body">            
                <p class="card-text">Untuk lebih mengetahui prodak kerudung ini silangkan klik tombol di bawahh ini</p>
                <a href="https://instagram.com/trihijab07?igshid=pcgvmg1c6vey" class="btn btn-primary">Instagram</a>
              </div>
            </div>
         </div>
       </div>
      </div>
     </div>
     </section>
    <!-- akhir card --> 
















    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>